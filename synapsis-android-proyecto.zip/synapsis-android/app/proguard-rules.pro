-keepclassmembers class app.synapsis.MediaBridge {
    @android.webkit.JavascriptInterface <methods>;
}
