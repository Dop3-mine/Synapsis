package app.synapsis

import android.content.ComponentName
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.MediaStore
import android.provider.Settings
import android.service.notification.NotificationListenerService
import android.util.Base64
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.widget.Toast
import androidx.core.app.NotificationManagerCompat
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File

/**
 * Puente entre la app web y Android. En JavaScript aparece como window.SynapsisNative.
 *  - Lee y controla las sesiones de medios de OTRAS apps (Spotify, YouTube Music...).
 *  - Guarda archivos exportados (Word, PDF, copias) en Descargas/Synapsis.
 *  - Mantiene la app viva con un servicio en primer plano mientras suena música.
 */
class MediaBridge(private val act: MainActivity, private val web: WebView) {

    private val ctx: Context = act.applicationContext
    private val main = Handler(Looper.getMainLooper())
    private val msm = ctx.getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager
    private val listenerComponent = ComponentName(ctx, MediaListenerService::class.java)

    private var listening = false
    private var controllers: List<MediaController> = emptyList()
    private var current: MediaController? = null
    private var preferred: String? = null

    private var artKey = ""
    private var artB64 = ""
    private var sentArtKey = "?"
    private var lastJson = ""

    private val sessionsListener =
        MediaSessionManager.OnActiveSessionsChangedListener { list -> onSessions(list ?: emptyList()) }

    private val callback = object : MediaController.Callback() {
        override fun onPlaybackStateChanged(state: PlaybackState?) { push() }
        override fun onMetadataChanged(metadata: MediaMetadata?) { push() }
        override fun onSessionDestroyed() { refresh() }
    }

    private val ticker = Runnable { push() }

    // ---------- Funciones que llama la app web ----------

    @JavascriptInterface
    fun isNative(): Boolean = true

    @JavascriptInterface
    fun hasAccess(): Boolean =
        NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName)

    @JavascriptInterface
    fun openAccessSettings() {
        main.post {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                try {
                    val detail = Intent(Settings.ACTION_NOTIFICATION_LISTENER_DETAIL_SETTINGS)
                        .putExtra(Settings.EXTRA_NOTIFICATION_LISTENER_COMPONENT_NAME, listenerComponent.flattenToString())
                    act.startActivity(detail)
                    return@post
                } catch (e: Exception) {
                }
            }
            try {
                act.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
            } catch (e: Exception) {
                act.startActivity(Intent(Settings.ACTION_SETTINGS))
            }
        }
    }

    @JavascriptInterface
    fun start() {
        main.post { if (listening) refresh() else startListening() }
    }

    @JavascriptInterface
    fun select(pkg: String) {
        main.post {
            preferred = pkg
            refresh()
        }
    }

    @JavascriptInterface
    fun command(cmd: String, arg: Double) {
        main.post {
            val c = current ?: return@post
            val t = c.transportControls
            when (cmd) {
                "play" -> t.play()
                "pause" -> t.pause()
                "toggle" -> if (isPlaying()) t.pause() else t.play()
                "next" -> t.skipToNext()
                "prev" -> t.skipToPrevious()
                "seek" -> t.seekTo(arg.toLong())
                "stop" -> t.stop()
            }
            main.postDelayed({ push() }, 300)
        }
    }

    @JavascriptInterface
    fun setPlaying(on: Boolean) {
        KeepAliveService.set(ctx, on)
    }

    @JavascriptInterface
    fun saveFile(name: String, mime: String, base64: String): Boolean {
        return try {
            val bytes = Base64.decode(base64, Base64.DEFAULT)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val values = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, name)
                    put(MediaStore.Downloads.MIME_TYPE, mime)
                    put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Synapsis")
                }
                val uri = ctx.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                    ?: return false
                ctx.contentResolver.openOutputStream(uri)?.use { it.write(bytes) } ?: return false
            } else {
                val dir = File(
                    Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
                    "Synapsis"
                )
                dir.mkdirs()
                File(dir, name).writeBytes(bytes)
            }
            main.post {
                Toast.makeText(ctx, "Guardado en Descargas/Synapsis: $name", Toast.LENGTH_LONG).show()
            }
            true
        } catch (e: Exception) {
            false
        }
    }

    // ---------- Ciclo de vida ----------

    fun onPageReady() {
        main.post {
            lastJson = ""
            sentArtKey = "?"
            push()
        }
    }

    fun onResume() {
        main.post { if (listening) refresh() else if (hasAccess()) startListening() }
    }

    fun shutdown() {
        main.removeCallbacks(ticker)
        controllers.forEach { try { it.unregisterCallback(callback) } catch (e: Exception) { } }
        try { msm.removeOnActiveSessionsChangedListener(sessionsListener) } catch (e: Exception) { }
        listening = false
    }

    // ---------- Lógica interna ----------

    private fun startListening() {
        if (!hasAccess()) { push(); return }
        if (!MediaListenerService.connected) {
            try {
                NotificationListenerService.requestRebind(listenerComponent)
            } catch (e: Exception) {
            }
        }
        try {
            msm.addOnActiveSessionsChangedListener(sessionsListener, listenerComponent, main)
            listening = true
            onSessions(msm.getActiveSessions(listenerComponent))
        } catch (e: SecurityException) {
            listening = false
            push()
        }
    }

    private fun refresh() {
        if (!hasAccess()) { push(); return }
        if (!listening) { startListening(); return }
        try {
            onSessions(msm.getActiveSessions(listenerComponent))
        } catch (e: SecurityException) {
            push()
        }
    }

    private fun onSessions(list: List<MediaController>) {
        controllers.forEach { try { it.unregisterCallback(callback) } catch (e: Exception) { } }
        controllers = list.filter { it.packageName != ctx.packageName }
        controllers.forEach { try { it.registerCallback(callback, main) } catch (e: Exception) { } }
        current = controllers.firstOrNull { it.packageName == preferred }
            ?: controllers.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING }
            ?: controllers.firstOrNull()
        push()
    }

    private fun isPlaying(): Boolean = current?.playbackState?.state == PlaybackState.STATE_PLAYING

    private fun push() {
        main.removeCallbacks(ticker)
        val js = state().toString()
        if (js != lastJson) {
            lastJson = js
            web.evaluateJavascript("window.__nativeMedia&&window.__nativeMedia($js)", null)
        }
        if (isPlaying()) main.postDelayed(ticker, 1000)
    }

    private fun label(pkg: String): String = try {
        val pm = ctx.packageManager
        pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
    } catch (e: Exception) {
        pkg
    }

    private fun bitmapB64(b: Bitmap?): String {
        if (b == null) return ""
        return try {
            val max = 256f
            val scale = minOf(1f, max / maxOf(b.width, b.height).toFloat())
            val bm = if (scale < 1f) {
                Bitmap.createScaledBitmap(
                    b,
                    (b.width * scale).toInt().coerceAtLeast(1),
                    (b.height * scale).toInt().coerceAtLeast(1),
                    true
                )
            } else b
            val out = ByteArrayOutputStream()
            bm.compress(Bitmap.CompressFormat.JPEG, 80, out)
            "data:image/jpeg;base64," + Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
        } catch (e: Exception) {
            ""
        }
    }

    private fun state(): JSONObject {
        val o = JSONObject()
        o.put("access", hasAccess())
        o.put("bound", MediaListenerService.connected)
        val apps = JSONArray()
        controllers.forEach {
            apps.put(
                JSONObject()
                    .put("pkg", it.packageName)
                    .put("name", label(it.packageName))
                    .put("playing", it.playbackState?.state == PlaybackState.STATE_PLAYING)
            )
        }
        o.put("apps", apps)

        val c = current
        if (c == null) {
            o.put("active", false)
            if (sentArtKey != "") { o.put("art", ""); sentArtKey = "" }
            return o
        }
        val m = c.metadata
        val ps = c.playbackState
        val title = m?.getString(MediaMetadata.METADATA_KEY_TITLE)
            ?: m?.getString(MediaMetadata.METADATA_KEY_DISPLAY_TITLE) ?: ""
        val artist = m?.getString(MediaMetadata.METADATA_KEY_ARTIST)
            ?: m?.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST)
            ?: m?.getString(MediaMetadata.METADATA_KEY_DISPLAY_SUBTITLE) ?: ""
        val dur = m?.getLong(MediaMetadata.METADATA_KEY_DURATION) ?: 0L

        var pos = ps?.position ?: 0L
        if (ps != null && ps.state == PlaybackState.STATE_PLAYING) {
            val dt = SystemClock.elapsedRealtime() - ps.lastPositionUpdateTime
            pos += (dt * ps.playbackSpeed).toLong()
        }
        if (dur > 0 && pos > dur) pos = dur
        if (pos < 0) pos = 0

        val actions = ps?.actions ?: 0L
        o.put("active", true)
        o.put("pkg", c.packageName)
        o.put("app", label(c.packageName))
        o.put("title", title)
        o.put("artist", artist)
        o.put("dur", dur)
        o.put("pos", pos)
        o.put("playing", ps?.state == PlaybackState.STATE_PLAYING)
        o.put("canNext", (actions and PlaybackState.ACTION_SKIP_TO_NEXT) != 0L)
        o.put("canPrev", (actions and PlaybackState.ACTION_SKIP_TO_PREVIOUS) != 0L)
        o.put("canSeek", (actions and PlaybackState.ACTION_SEEK_TO) != 0L)

        // La portada se envía solo cuando cambia la canción, para no repetirla cada segundo.
        val key = c.packageName + "|" + title + "|" + artist
        if (key != artKey) {
            artKey = key
            artB64 = bitmapB64(
                m?.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
                    ?: m?.getBitmap(MediaMetadata.METADATA_KEY_ART)
                    ?: m?.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON)
            )
        }
        if (sentArtKey != artKey) {
            o.put("art", artB64)
            sentArtKey = artKey
        }
        return o
    }
}
