package app.synapsis

import android.service.notification.NotificationListenerService

/**
 * Servicio vacío a propósito: al activarlo el usuario en "Acceso a notificaciones",
 * Android permite a la app leer las sesiones de medios activas (MediaSessionManager).
 */
class MediaListenerService : NotificationListenerService()
