package app.synapsis

import android.service.notification.NotificationListenerService

/**
 * Al activarlo el usuario en "Acceso a notificaciones", Android permite a la app leer las
 * sesiones de medios activas (MediaSessionManager). Aquí solo se anota si está conectado.
 */
class MediaListenerService : NotificationListenerService() {

    companion object {
        @Volatile
        var connected = false
    }

    override fun onListenerConnected() {
        connected = true
        super.onListenerConnected()
    }

    override fun onListenerDisconnected() {
        connected = false
        super.onListenerDisconnected()
    }
}
