# Synapsis para Android (proyecto)

Esta carpeta es un proyecto de **Android Studio** que envuelve la app web de Synapsis en una app nativa y le agrega:

- **Música de otras apps:** el reproductor muestra y controla lo que suena en Spotify, YouTube Music y otras apps (pausa, anterior, siguiente y barra de progreso).
- **Reproducción en segundo plano:** un servicio en primer plano evita que Android cierre la app mientras suena música.
- **Guardar archivos:** Word, PDF y copias de seguridad se guardan en `Descargas/Synapsis`.
- **Botón atrás** que no cierra la música y enlaces externos (Google, Claude, Lens) que abren en el navegador.

> **Importante:** este proyecto lo preparé sin poder compilarlo ni probarlo en un dispositivo. Puede necesitar pequeños ajustes al abrirlo por primera vez (versiones de Gradle o de librerías). Si Android Studio muestra errores, copia el mensaje y te ayudo a corregirlo.

## 1. Compilar e instalar (la primera vez)

1. Instala **Android Studio** (versión reciente) desde developer.android.com/studio.
2. Abre Android Studio → **File → Open** → elige la carpeta `synapsis-android`.
3. Espera a que termine la sincronización de Gradle (necesita internet). Si te propone actualizar Gradle o el plugin, acepta solo si hay un error; si no, déjalo.
4. En tu celular o tablet: activa **Opciones de desarrollador** (toca 7 veces el número de compilación en Ajustes → Información del teléfono) y luego **Depuración por USB**.
5. Conecta el dispositivo, elígelo arriba en Android Studio y pulsa **Run ▶**.

### Solo quiero el archivo .apk
**Build → Build Bundle(s) / APK(s) → Build APK(s)**. El archivo queda en `app/build/outputs/apk/debug/app-debug.apk`. Pásalo al dispositivo e instálalo (permite instalar de orígenes desconocidos cuando Android lo pida).

### Alternativa sin instalar Android Studio: compilar en la nube (GitHub)
1. Crea una cuenta gratuita en github.com y un repositorio nuevo.
2. Sube **el contenido** de esta carpeta (no la carpeta contenedora) a la raíz del repositorio. Debe verse `app`, `build.gradle.kts` y `.github` en la raíz. Desde un computador puedes arrastrar los archivos en «Add file → Upload files».
3. Abre la pestaña **Actions → Compilar APK de Synapsis → Run workflow**. Tarda unos minutos.
4. Cuando termine, entra a esa ejecución y descarga **synapsis-apk** (un .zip con `app-debug.apk` adentro). Instálalo en tu dispositivo.

## 2. Activar la música de otras apps

1. Abre Synapsis, toca el botón redondo del reproductor (abajo a la derecha) y luego el **icono del teléfono**.
2. Toca **Abrir ajustes** y activa **Synapsis** en **Acceso a notificaciones**.
   - Si Android dice «Ajuste restringido» (pasa con apps instaladas fuera de Play Store): Ajustes → Apps → Synapsis → menú ⋮ → **Permitir ajustes restringidos**, y vuelve a intentarlo.
3. Pon música en otra app. Debería aparecer en el reproductor de Synapsis con sus controles.

## 3. Tus datos

La app nativa guarda sus datos aparte de la versión web de Chrome o Netlify. Para pasarlos:
**Ajustes → Copia de seguridad → Guardar copia** en la versión web, y **Restaurar copia** en la nativa (elige el archivo `.json`).

## 4. Actualizar el contenido de la app

El contenido de Synapsis está en `app/src/main/assets/www/index.html`. Cuando recibas una versión nueva, reemplaza ese archivo y vuelve a compilar.

## 5. Publicar en Google Play (cuando quieras)

1. Cambia el identificador en `app/build.gradle.kts` (`applicationId = "app.synapsis"`) por uno propio y único, por ejemplo `com.tunombre.synapsis`.
2. **Build → Generate Signed Bundle / APK → Android App Bundle**. Crea una llave (keystore) y **guárdala y respáldala**: sin ella no podrás actualizar la app.
3. Crea una cuenta de desarrollador de Google Play (pago único de unos 25 dólares) y sube el `.aab`.
4. Google pedirá una **política de privacidad**, la ficha de seguridad de datos y justificar el permiso de **Acceso a notificaciones**, que se usa solo para leer la música en reproducción. El icono para la ficha está en `icono-play-store-512.png`.
5. Las cuentas personales nuevas deben pasar una fase de pruebas cerrada con testers antes de publicar.

## 6. Cosas que conviene saber

- Los reproductores de YouTube, Spotify, SoundCloud y Deezer dentro de la app dependen de que esos servicios acepten reproducir dentro de una WebView; puede salir algún error de reproducción que haya que ajustar.
- Android 13 o superior pide permiso para mostrar notificaciones; la app lo solicita al abrir (se usa para el aviso de «Reproduciendo música»).
- Para que Android no cierre la app en segundo plano, en los ajustes de batería del dispositivo ponla en «Sin restricciones».
